# CYBERDUDEBIVASH SENTINEL APEX Sigma Rules

Generated: 2026-11-23T03:54:38.644697+00:00
Version: 162.0.0

Use sigma-cli to convert to your target SIEM format:
```
sigma convert -t splunk apex/*.yml
sigma convert -t microsoft365defender apex/*.yml
```
