# CYBERDUDEBIVASH SENTINEL APEX Sigma Rules

Generated: 2026-11-25T03:56:07.343899+00:00
Version: 162.0.0

Use sigma-cli to convert to your target SIEM format:
```
sigma convert -t splunk apex/*.yml
sigma convert -t microsoft365defender apex/*.yml
```
